export interface SessionRequest {
	name: string
	description: string | null
	capacity: number
	date: string
	startTime: string
	endTime: string
	goal: string | null
	intensity: string
	image: File | null
	employeeId: number | null
}
